Disciples III Unit - Blender add-on 1.1.45
=====================================

Install: Edit > Preferences > Add-ons > Install... and pick this
zip.  Enable 'Disciples III Unit (GM .g/.a/.scene/.ac/.t)'.

Import: File > Import > Disciples III Unit, pick the unit's .g.
Export: File > Export > Disciples III Unit, pick the .g to write.

The zip vendors the d3tool library it was built from; the add-on
preferences can point at another copy (Check d3tool reports which
one is loaded).

Source: https://github.com/travagant/geo2011
